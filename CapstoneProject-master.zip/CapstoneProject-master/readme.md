If the error unexpected EOF appears in the cmd
cmd -> ren .env.example .env
cmd -> php artisan key:generate
cmd -> php artisan config:clear

Then the problem should be solved.